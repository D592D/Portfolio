package com.example.sortly;

/**
 * Data model representing an item in the inventory.
 *
 * Encapsulates item details including the owner's userId foreign key to isolate
 * inventory records per user account.
 */
public class InventoryItem {
    private long id;
    private long userId;
    private String name;
    private int quantity;

    /**
     * Constructor for creating a new item associated with a specific user account.
     *
     * @param userId   The database ID of the user who owns this item.
     * @param name     The name of the item.
     * @param quantity The initial quantity of the item.
     */
    public InventoryItem(long userId, String name, int quantity) {
        this.userId = userId;
        setName(name);
        setQuantity(quantity);
    }

    /**
     * Constructor for creating a new item without an explicit user ID (defaults to 0 until assigned).
     *
     * @param name     The name of the item.
     * @param quantity The initial quantity of the item.
     */
    public InventoryItem(String name, int quantity) {
        this(0, name, quantity);
    }

    /**
     * Constructor for an existing item fetched from the database.
     *
     * @param id       The database ID of the inventory record.
     * @param userId   The database ID of the owning user account.
     * @param name     The name of the item.
     * @param quantity The quantity of the item.
     */
    public InventoryItem(long id, long userId, String name, int quantity) {
        this.id = id;
        this.userId = userId;
        setName(name);
        setQuantity(quantity);
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Item name cannot be null or empty.");
        }
        this.name = name;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        if (quantity < 0) {
            throw new IllegalArgumentException("Quantity cannot be negative.");
        }
        this.quantity = quantity;
    }
}
