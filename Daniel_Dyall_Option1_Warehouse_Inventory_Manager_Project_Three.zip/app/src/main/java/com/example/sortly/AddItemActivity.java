package com.example.sortly;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

/**
 * AddItemActivity provides a dedicated, user-centered data entry form
 * to add new inventory records linked to the active user's account in SQLite.
 */
public class AddItemActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private TextInputLayout tilName;
    private TextInputLayout tilQuantity;
    private TextInputEditText etName;
    private TextInputEditText etQuantity;
    private long currentUserId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        dbHelper = new DatabaseHelper(this);

        // Retrieve active user ID from Intent or SharedPreferences
        SharedPreferences prefs = getSharedPreferences(LoginActivity.PREFS_NAME, MODE_PRIVATE);
        currentUserId = getIntent().getLongExtra(
                LoginActivity.EXTRA_USER_ID,
                prefs.getLong(LoginActivity.KEY_LOGGED_IN_USER_ID, -1)
        );

        tilName = findViewById(R.id.tilItemName);
        tilQuantity = findViewById(R.id.tilItemQuantity);
        etName = findViewById(R.id.etItemName);
        etQuantity = findViewById(R.id.etItemQuantity);

        MaterialButton btnSave = findViewById(R.id.btnSaveItem);
        MaterialButton btnCancel = findViewById(R.id.btnCancelItem);

        btnSave.setOnClickListener(v -> saveItem());
        btnCancel.setOnClickListener(v -> finish());
    }

    /**
     * Validates input fields and saves the new inventory record linked to currentUserId.
     */
    private void saveItem() {
        String name = etName.getText() != null ? etName.getText().toString().trim() : "";
        String quantityStr = etQuantity.getText() != null ? etQuantity.getText().toString().trim() : "";

        tilName.setError(null);
        tilQuantity.setError(null);

        // Name validation
        if (TextUtils.isEmpty(name)) {
            tilName.setError("Item name cannot be empty");
            etName.requestFocus();
            return;
        }

        // Quantity validation
        if (TextUtils.isEmpty(quantityStr)) {
            tilQuantity.setError("Please enter an initial quantity");
            etQuantity.requestFocus();
            return;
        }

        int quantity;
        try {
            quantity = Integer.parseInt(quantityStr);
            if (quantity < 0) {
                tilQuantity.setError("Quantity cannot be negative");
                etQuantity.requestFocus();
                return;
            }
        } catch (NumberFormatException e) {
            tilQuantity.setError("Please enter a valid numeric integer");
            etQuantity.requestFocus();
            return;
        }

        // Insert into database linked to the current user's account
        InventoryItem newItem = new InventoryItem(currentUserId, name, quantity);
        boolean isInserted = dbHelper.insertInventoryItem(newItem, currentUserId);

        if (isInserted) {
            Toast.makeText(this, "Item added successfully", Toast.LENGTH_SHORT).show();
            finish(); // Returns to InventoryActivity
        } else {
            Toast.makeText(this, "Database insertion failed", Toast.LENGTH_SHORT).show();
        }
    }
}
