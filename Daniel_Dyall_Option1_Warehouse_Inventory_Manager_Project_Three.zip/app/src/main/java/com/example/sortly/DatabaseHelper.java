package com.example.sortly;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Base64;
import android.util.Log;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.List;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/**
 * SQLiteOpenHelper implementation for managing the local database.
 *
 * Security & Relational Design:
 * - Passwords are never stored in plain text. Uses cryptographic salting (16-byte SecureRandom)
 *   and PBKDF2WithHmacSHA256 key derivation before persisting or verifying credentials.
 * - Enforces foreign key relationships (COLUMN_INV_USER_ID -> Users.id) so each user account
 *   maintains its own isolated, persistent inventory records.
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String TAG = "DatabaseHelper";
    private static final String DATABASE_NAME = "inventory_manager.db";
    private static final int DATABASE_VERSION = 2;

    // PBKDF2 Hashing Parameters
    private static final String PBKDF2_ALGORITHM = "PBKDF2WithHmacSHA256";
    private static final int SALT_BYTE_SIZE = 16;
    private static final int HASH_BIT_SIZE = 256;
    private static final int PBKDF2_ITERATIONS = 10000;

    // Users Table
    public static final String TABLE_USERS = "Users";
    public static final String COLUMN_USER_ID = "id";
    public static final String COLUMN_USER_USERNAME = "username";
    public static final String COLUMN_USER_PASSWORD_HASH = "password_hash";
    public static final String COLUMN_USER_SALT = "salt";

    // Inventory Table (Linked to Users table via user_id foreign key)
    public static final String TABLE_INVENTORY = "Inventory";
    public static final String COLUMN_INV_ID = "id";
    public static final String COLUMN_INV_USER_ID = "user_id";
    public static final String COLUMN_INV_NAME = "name";
    public static final String COLUMN_INV_QUANTITY = "quantity";

    // SQL statement to create Users table with password hash and cryptographic salt
    private static final String TABLE_CREATE_USERS =
            "CREATE TABLE " + TABLE_USERS + " (" +
            COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            COLUMN_USER_USERNAME + " TEXT UNIQUE NOT NULL, " +
            COLUMN_USER_PASSWORD_HASH + " TEXT NOT NULL, " +
            COLUMN_USER_SALT + " TEXT NOT NULL);";

    // SQL statement to create Inventory table with user_id Foreign Key
    private static final String TABLE_CREATE_INVENTORY =
            "CREATE TABLE " + TABLE_INVENTORY + " (" +
            COLUMN_INV_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            COLUMN_INV_USER_ID + " INTEGER NOT NULL, " +
            COLUMN_INV_NAME + " TEXT NOT NULL, " +
            COLUMN_INV_QUANTITY + " INTEGER NOT NULL DEFAULT 0, " +
            "FOREIGN KEY(" + COLUMN_INV_USER_ID + ") REFERENCES " +
            TABLE_USERS + "(" + COLUMN_USER_ID + ") ON DELETE CASCADE);";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        // Enable foreign key constraints enforcement in SQLite
        db.setForeignKeyConstraintsEnabled(true);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(TABLE_CREATE_USERS);
        db.execSQL(TABLE_CREATE_INVENTORY);

        // Pre-populate default admin account with salted PBKDF2 hash
        insertUserInternal(db, "admin", "password123");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_INVENTORY);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }

    // ==========================================
    // Cryptographic Password Hashing & Salting
    // ==========================================

    /**
     * Generates a cryptographically random 16-byte salt encoded as Base64.
     */
    private String generateSalt() {
        SecureRandom random = new SecureRandom();
        byte[] salt = new byte[SALT_BYTE_SIZE];
        random.nextBytes(salt);
        return Base64.encodeToString(salt, Base64.NO_WRAP);
    }

    /**
     * Hashes a plain-text password using PBKDF2WithHmacSHA256 and the provided Base64 salt.
     */
    private String hashPassword(String password, String saltBase64) {
        try {
            byte[] salt = Base64.decode(saltBase64, Base64.NO_WRAP);
            PBEKeySpec spec = new PBEKeySpec(
                    password.toCharArray(),
                    salt,
                    PBKDF2_ITERATIONS,
                    HASH_BIT_SIZE
            );
            SecretKeyFactory factory = SecretKeyFactory.getInstance(PBKDF2_ALGORITHM);
            byte[] hash = factory.generateSecret(spec).getEncoded();
            return Base64.encodeToString(hash, Base64.NO_WRAP);
        } catch (NoSuchAlgorithmException | InvalidKeySpecException e) {
            Log.e(TAG, "Error hashing password with PBKDF2", e);
            return null;
        }
    }

    /**
     * Helper to insert a user record with salted PBKDF2 password hash into a provided SQLiteDatabase.
     */
    private long insertUserInternal(SQLiteDatabase db, String username, String password) {
        String salt = generateSalt();
        String passwordHash = hashPassword(password, salt);
        if (passwordHash == null) {
            return -1;
        }

        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_USERNAME, username.trim().toLowerCase());
        values.put(COLUMN_USER_PASSWORD_HASH, passwordHash);
        values.put(COLUMN_USER_SALT, salt);

        long result = -1;
        try {
            result = db.insert(TABLE_USERS, null, values);
        } catch (Exception e) {
            Log.e(TAG, "Error during user insertion", e);
        }
        return result;
    }

    // ==========================================
    // User Authentication Operations
    // ==========================================

    /**
     * Registers a new user account in the SQLite database using a unique salt and PBKDF2 hash.
     *
     * @param username The chosen username.
     * @param password The plain-text password to be salted and hashed.
     * @return The new user's row ID (> 0) if successful, or -1 if registration fails.
     */
    public long registerUser(String username, String password) {
        if (username == null || username.trim().isEmpty() || password == null || password.trim().isEmpty()) {
            return -1;
        }
        SQLiteDatabase db = this.getWritableDatabase();
        return insertUserInternal(db, username, password);
    }

    /**
     * Authenticates a user by retrieving their stored salt, hashing the supplied password
     * with PBKDF2WithHmacSHA256, and performing a constant-time comparison.
     *
     * @param username The username to authenticate.
     * @param password The plain-text password entered by the user.
     * @return The authenticated user's ID (> 0) if valid, or -1 if authentication fails.
     */
    public long authenticateUser(String username, String password) {
        if (username == null || username.trim().isEmpty() || password == null || password.trim().isEmpty()) {
            return -1;
        }

        SQLiteDatabase db = this.getReadableDatabase();
        String selection = COLUMN_USER_USERNAME + " = ?";
        String[] selectionArgs = {username.trim().toLowerCase()};

        try (Cursor cursor = db.query(
                TABLE_USERS,
                new String[]{COLUMN_USER_ID, COLUMN_USER_PASSWORD_HASH, COLUMN_USER_SALT},
                selection,
                selectionArgs,
                null, null, null)) {

            if (cursor != null && cursor.moveToFirst()) {
                long userId = cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_USER_ID));
                String storedHash = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_USER_PASSWORD_HASH));
                String storedSalt = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_USER_SALT));

                String computedHash = hashPassword(password, storedSalt);
                if (computedHash != null && storedHash != null &&
                        MessageDigest.isEqual(computedHash.getBytes(), storedHash.getBytes())) {
                    return userId;
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Error during authentication query", e);
        }
        return -1;
    }

    // ==========================================
    // User-Isolated CRUD Operations for Inventory
    // ==========================================

    /**
     * Create (Insert) a new inventory item linked to a specific user account.
     */
    public boolean insertInventoryItem(InventoryItem item, long userId) {
        if (item == null || userId <= 0 || item.getName() == null ||
                item.getName().trim().isEmpty() || item.getQuantity() < 0) {
            return false;
        }

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_INV_USER_ID, userId);
        values.put(COLUMN_INV_NAME, item.getName().trim());
        values.put(COLUMN_INV_QUANTITY, item.getQuantity());

        long result = db.insert(TABLE_INVENTORY, null, values);
        if (result != -1) {
            item.setId(result);
            item.setUserId(userId);
            return true;
        }
        return false;
    }

    /**
     * Read (Select) all inventory items belonging to a specific user account in alphabetical order.
     */
    public List<InventoryItem> getAllInventoryItemsForUser(long userId) {
        List<InventoryItem> items = new ArrayList<>();
        if (userId <= 0) {
            return items;
        }

        SQLiteDatabase db = this.getReadableDatabase();
        String selection = COLUMN_INV_USER_ID + " = ?";
        String[] selectionArgs = {String.valueOf(userId)};

        try (Cursor cursor = db.query(
                TABLE_INVENTORY,
                null,
                selection,
                selectionArgs,
                null, null,
                COLUMN_INV_NAME + " ASC")) {

            if (cursor != null && cursor.moveToFirst()) {
                int idIndex = cursor.getColumnIndexOrThrow(COLUMN_INV_ID);
                int userIdIndex = cursor.getColumnIndexOrThrow(COLUMN_INV_USER_ID);
                int nameIndex = cursor.getColumnIndexOrThrow(COLUMN_INV_NAME);
                int qtyIndex = cursor.getColumnIndexOrThrow(COLUMN_INV_QUANTITY);

                do {
                    long id = cursor.getLong(idIndex);
                    long ownerId = cursor.getLong(userIdIndex);
                    String name = cursor.getString(nameIndex);
                    int qty = cursor.getInt(qtyIndex);
                    items.add(new InventoryItem(id, ownerId, name, qty));
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.e(TAG, "Error fetching user inventory items", e);
        }
        return items;
    }

    /**
     * Update an existing inventory item's quantity, scoped to the owning user account.
     */
    public boolean updateInventoryItem(InventoryItem item, long userId) {
        if (item == null || item.getId() <= 0 || userId <= 0 || item.getQuantity() < 0) {
            return false;
        }

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_INV_NAME, item.getName());
        values.put(COLUMN_INV_QUANTITY, item.getQuantity());

        String selection = COLUMN_INV_ID + " = ? AND " + COLUMN_INV_USER_ID + " = ?";
        String[] selectionArgs = {String.valueOf(item.getId()), String.valueOf(userId)};

        int rows = db.update(TABLE_INVENTORY, values, selection, selectionArgs);
        return rows > 0;
    }

    /**
     * Delete an inventory item by ID, scoped to the owning user account.
     */
    public boolean deleteInventoryItem(long itemId, long userId) {
        if (itemId <= 0 || userId <= 0) {
            return false;
        }

        SQLiteDatabase db = this.getWritableDatabase();
        String selection = COLUMN_INV_ID + " = ? AND " + COLUMN_INV_USER_ID + " = ?";
        String[] selectionArgs = {String.valueOf(itemId), String.valueOf(userId)};

        int rows = db.delete(TABLE_INVENTORY, selection, selectionArgs);
        return rows > 0;
    }
}
