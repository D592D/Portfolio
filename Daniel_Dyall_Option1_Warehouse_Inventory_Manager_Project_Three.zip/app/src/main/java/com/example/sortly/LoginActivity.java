package com.example.sortly;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

/**
 * LoginActivity handles user authentication and initial account registration.
 *
 * Security & Session Standards:
 * - Pre-validates user inputs before querying the SQLite database to save I/O resources.
 * - Authenticates and registers users using PBKDF2WithHmacSHA256 salted password hashes.
 * - Persists the authenticated userId in SharedPreferences and passes it via Intent extras
 *   so each user accesses only their own isolated inventory records.
 */
public class LoginActivity extends AppCompatActivity {

    public static final String PREFS_NAME = "InventoryAppPrefs";
    public static final String KEY_LOGGED_IN_USER_ID = "logged_in_user_id";
    public static final String EXTRA_USER_ID = "extra_user_id";

    private TextInputLayout tilUsername;
    private TextInputLayout tilPassword;
    private TextInputEditText etUsername;
    private TextInputEditText etPassword;

    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Initialize SQLite Database Helper
        dbHelper = new DatabaseHelper(this);

        // Bind Views
        tilUsername = findViewById(R.id.tilUsername);
        tilPassword = findViewById(R.id.tilPassword);
        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        MaterialButton btnLogin = findViewById(R.id.btnLogin);
        MaterialButton btnRegister = findViewById(R.id.btnRegister);

        // Set up click listeners
        btnLogin.setOnClickListener(v -> attemptLogin());
        btnRegister.setOnClickListener(v -> attemptRegistration());
    }

    /**
     * Authenticates an existing user against the SQLite database using salted PBKDF2 verification.
     */
    private void attemptLogin() {
        String username = etUsername.getText() != null ? etUsername.getText().toString().trim() : "";
        String password = etPassword.getText() != null ? etPassword.getText().toString().trim() : "";

        tilUsername.setError(null);
        tilPassword.setError(null);

        // Pre-validation checks
        if (TextUtils.isEmpty(username)) {
            tilUsername.setError("Username cannot be empty");
            etUsername.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(password)) {
            tilPassword.setError("Password cannot be empty");
            etPassword.requestFocus();
            return;
        }

        // Database verification (returns user ID > 0 if authenticated, -1 otherwise)
        long userId = dbHelper.authenticateUser(username, password);

        if (userId > 0) {
            Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show();
            navigateToInventory(userId);
        } else {
            Toast.makeText(this, "Invalid credentials. Please try again or create an account.", Toast.LENGTH_LONG).show();
        }
    }

    /**
     * Registers a new user account with salted PBKDF2 password hashing if one does not already exist.
     */
    private void attemptRegistration() {
        String username = etUsername.getText() != null ? etUsername.getText().toString().trim() : "";
        String password = etPassword.getText() != null ? etPassword.getText().toString().trim() : "";

        tilUsername.setError(null);
        tilPassword.setError(null);

        // Pre-validation checks
        if (TextUtils.isEmpty(username)) {
            tilUsername.setError("Username cannot be empty");
            etUsername.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(password)) {
            tilPassword.setError("Password cannot be empty");
            etPassword.requestFocus();
            return;
        }

        if (password.length() < 4) {
            tilPassword.setError("Password must be at least 4 characters");
            etPassword.requestFocus();
            return;
        }

        // Insert new user into database (returns new user ID > 0 if created, -1 otherwise)
        long newUserId = dbHelper.registerUser(username, password);

        if (newUserId > 0) {
            Toast.makeText(this, "Account created successfully! Welcome.", Toast.LENGTH_SHORT).show();
            navigateToInventory(newUserId);
        } else {
            tilUsername.setError("Username already exists. Please choose another.");
            etUsername.requestFocus();
        }
    }

    /**
     * Saves the active userId session, transitions to InventoryActivity, and clears the back stack.
     */
    private void navigateToInventory(long userId) {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit().putLong(KEY_LOGGED_IN_USER_ID, userId).apply();

        Intent intent = new Intent(LoginActivity.this, InventoryActivity.class);
        intent.putExtra(EXTRA_USER_ID, userId);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }
}
