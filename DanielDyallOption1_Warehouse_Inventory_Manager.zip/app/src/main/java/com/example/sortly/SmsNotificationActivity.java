package com.example.sortly;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.TextUtils;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.switchmaterial.SwitchMaterial;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

/**
 * SmsNotificationActivity provides a dedicated UI screen to prompt the user for
 * SEND_SMS permission, display real-time status and feedback based on user choices,
 * and configure low-stock SMS alert preferences.
 */
public class SmsNotificationActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_REQUEST_CODE = 102;
    public static final String PREFS_NAME = "InventoryAppPrefs";
    public static final String KEY_ALERT_PHONE = "alert_phone_number";
    public static final String KEY_SMS_ENABLED = "sms_alerts_enabled";
    public static final String DEFAULT_PHONE = "5551234567";

    private TextView tvPermissionStatusValue;
    private TextView tvUserResponseFeedback;
    private SwitchMaterial switchEnableSms;
    private TextInputLayout tilPhoneNumber;
    private TextInputEditText etPhoneNumber;
    private MaterialButton btnGrantSmsPermission;
    private MaterialButton btnDeclineSmsPermission;
    private MaterialButton btnSaveSmsSettings;
    private MaterialButton btnSendTestSms;

    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_notification);

        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        // Bind UI components
        tvPermissionStatusValue = findViewById(R.id.tvPermissionStatusValue);
        tvUserResponseFeedback = findViewById(R.id.tvUserResponseFeedback);
        switchEnableSms = findViewById(R.id.switchEnableSms);
        tilPhoneNumber = findViewById(R.id.tilPhoneNumber);
        etPhoneNumber = findViewById(R.id.etPhoneNumber);
        btnGrantSmsPermission = findViewById(R.id.btnGrantSmsPermission);
        btnDeclineSmsPermission = findViewById(R.id.btnDeclineSmsPermission);
        btnSaveSmsSettings = findViewById(R.id.btnSaveSmsSettings);
        btnSendTestSms = findViewById(R.id.btnSendTestSms);
        MaterialButton btnBackToInventory = findViewById(R.id.btnBackToInventory);

        // Load saved preferences
        String savedPhone = prefs.getString(KEY_ALERT_PHONE, DEFAULT_PHONE);
        boolean smsEnabled = prefs.getBoolean(KEY_SMS_ENABLED, true);
        etPhoneNumber.setText(savedPhone);
        switchEnableSms.setChecked(smsEnabled);

        // Refresh permission UI status
        updatePermissionStatusUi();

        // Button listeners
        btnGrantSmsPermission.setOnClickListener(v -> requestSmsPermissionFromUser());

        btnDeclineSmsPermission.setOnClickListener(v -> {
            switchEnableSms.setChecked(false);
            prefs.edit().putBoolean(KEY_SMS_ENABLED, false).apply();
            updatePermissionStatusUi();
            Toast.makeText(this, "SMS alerts disabled. App will continue to function without notifications.", Toast.LENGTH_SHORT).show();
        });

        switchEnableSms.setOnCheckedChangeListener((buttonView, isChecked) -> {
            prefs.edit().putBoolean(KEY_SMS_ENABLED, isChecked).apply();
            updatePermissionStatusUi();
        });

        btnSaveSmsSettings.setOnClickListener(v -> savePreferences());

        btnSendTestSms.setOnClickListener(v -> sendTestSmsAlert());

        btnBackToInventory.setOnClickListener(v -> finish());
    }

    @Override
    protected void onResume() {
        super.onResume();
        updatePermissionStatusUi();
    }

    /**
     * Checks whether SEND_SMS permission is granted and updates the screen UI
     * to display clear feedback based on the user's permission response and toggle state.
     */
    private void updatePermissionStatusUi() {
        boolean hasPermission = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
        boolean isEnabledByPref = switchEnableSms.isChecked();

        if (hasPermission && isEnabledByPref) {
            tvPermissionStatusValue.setText("GRANTED (SMS Alerts Active)");
            tvPermissionStatusValue.setTextColor(Color.parseColor("#4CAF50"));
            tvUserResponseFeedback.setText("Permission granted: You will receive automated SMS text notifications whenever an inventory item is reduced to zero quantity.");
            btnGrantSmsPermission.setEnabled(false);
            btnGrantSmsPermission.setText("SMS Permission Already Granted");
        } else if (hasPermission) {
            tvPermissionStatusValue.setText("GRANTED (Paused by User Preference)");
            tvPermissionStatusValue.setTextColor(Color.parseColor("#FF9800"));
            tvUserResponseFeedback.setText("System SMS permission is granted, but notifications are currently toggled off below. The app will continue functioning without sending SMS alerts.");
            btnGrantSmsPermission.setEnabled(false);
            btnGrantSmsPermission.setText("SMS Permission Already Granted");
        } else {
            tvPermissionStatusValue.setText("NOT GRANTED / DENIED");
            tvPermissionStatusValue.setTextColor(Color.parseColor("#F44336"));
            tvUserResponseFeedback.setText("Permission not granted: Automated SMS low-stock notifications are disabled. The application will continue to function normally for all inventory tracking operations.");
            btnGrantSmsPermission.setEnabled(true);
            btnGrantSmsPermission.setText(R.string.btn_grant_permission);
        }
    }

    /**
     * Triggers the Android runtime permission prompt for SEND_SMS.
     */
    private void requestSmsPermissionFromUser() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            switchEnableSms.setChecked(true);
            prefs.edit().putBoolean(KEY_SMS_ENABLED, true).apply();
            updatePermissionStatusUi();
            Toast.makeText(this, "SMS permission is already granted.", Toast.LENGTH_SHORT).show();
        } else {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_REQUEST_CODE
            );
        }
    }

    /**
     * Validates and saves the notification recipient phone number and toggle preference.
     */
    private void savePreferences() {
        String phone = etPhoneNumber.getText() != null ? etPhoneNumber.getText().toString().trim() : "";
        tilPhoneNumber.setError(null);

        if (TextUtils.isEmpty(phone)) {
            tilPhoneNumber.setError("Please enter a valid recipient phone number");
            etPhoneNumber.requestFocus();
            return;
        }

        boolean enabled = switchEnableSms.isChecked();
        prefs.edit()
                .putString(KEY_ALERT_PHONE, phone)
                .putBoolean(KEY_SMS_ENABLED, enabled)
                .apply();

        updatePermissionStatusUi();
        Toast.makeText(this, "Notification preferences saved", Toast.LENGTH_SHORT).show();
    }

    /**
     * Sends a test SMS message if permission is granted and notifications are enabled.
     */
    private void sendTestSmsAlert() {
        boolean hasPermission = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;

        if (!hasPermission) {
            Toast.makeText(this, "Cannot send test SMS: Permission not granted. Please tap 'Request / Grant SMS Permission' first.", Toast.LENGTH_LONG).show();
            requestSmsPermissionFromUser();
            return;
        }

        if (!switchEnableSms.isChecked()) {
            Toast.makeText(this, "SMS alerts are currently toggled off.", Toast.LENGTH_SHORT).show();
            return;
        }

        String phone = etPhoneNumber.getText() != null ? etPhoneNumber.getText().toString().trim() : DEFAULT_PHONE;
        if (TextUtils.isEmpty(phone)) {
            phone = DEFAULT_PHONE;
        }

        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phone, null,
                    "WAREHOUSE INVENTORY ALERT: Test notification confirmed. Zero-stock SMS alerts are active.",
                    null, null);
            Toast.makeText(this, "Test SMS alert sent to " + phone, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Failed to dispatch test SMS", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                switchEnableSms.setChecked(true);
                prefs.edit().putBoolean(KEY_SMS_ENABLED, true).apply();
                Toast.makeText(this, "SMS permission granted! Automated low-stock alerts enabled.", Toast.LENGTH_SHORT).show();
            } else {
                switchEnableSms.setChecked(false);
                prefs.edit().putBoolean(KEY_SMS_ENABLED, false).apply();
                Toast.makeText(this, "SMS permission denied. App will continue to function without notifications.", Toast.LENGTH_LONG).show();
            }
            updatePermissionStatusUi();
        }
    }
}
