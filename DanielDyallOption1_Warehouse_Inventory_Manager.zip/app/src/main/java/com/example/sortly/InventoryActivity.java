package com.example.sortly;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

/**
 * InventoryActivity displays the warehouse inventory in a 2-column grid.
 *
 * Implemented Features:
 * - 2-Column GridLayoutManager with RecyclerView for high performance.
 * - Empty state feedback when no items exist.
 * - Navigation to dedicated SmsNotificationActivity screen via the top toolbar.
 * - Dynamic SMS notification workflow triggered when any item stock reaches 0.
 * - Graceful permission handling: rationales, user prompts, and non-blocking degradation.
 * - Modal confirmation dialogs for destructive delete operations.
 */
public class InventoryActivity extends AppCompatActivity implements InventoryAdapter.OnItemActionListener {

    private static final int SMS_PERMISSION_REQUEST_CODE = 101;
    private static final String PREFS_NAME = "InventoryAppPrefs";
    private static final String KEY_ALERT_PHONE = "alert_phone_number";
    private static final String KEY_SMS_ENABLED = "sms_alerts_enabled";
    private static final String DEFAULT_PHONE = "5551234567";

    private RecyclerView recyclerView;
    private TextView tvEmptyState;
    private InventoryAdapter adapter;
    private DatabaseHelper dbHelper;
    private final List<InventoryItem> items = new ArrayList<>();

    private String pendingAlertItemName = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        // Setup Toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        dbHelper = new DatabaseHelper(this);

        recyclerView = findViewById(R.id.recyclerViewInventory);
        tvEmptyState = findViewById(R.id.tvEmptyState);

        // Use 2-column GridLayoutManager
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));
        adapter = new InventoryAdapter(items, this);
        recyclerView.setAdapter(adapter);

        // FAB launches the dedicated AddItemActivity form
        FloatingActionButton fabAddItem = findViewById(R.id.fabAddItem);
        fabAddItem.setOnClickListener(v -> {
            Intent intent = new Intent(InventoryActivity.this, AddItemActivity.class);
            startActivity(intent);
        });

        loadInventory();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadInventory();
    }

    /**
     * Loads all inventory records from SQLite and updates the UI and empty state.
     */
    private void loadInventory() {
        items.clear();
        items.addAll(dbHelper.getAllInventoryItems());
        adapter.notifyDataSetChanged();

        if (items.isEmpty()) {
            tvEmptyState.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.GONE);
        } else {
            tvEmptyState.setVisibility(View.GONE);
            recyclerView.setVisibility(View.VISIBLE);
        }
    }

    // ==========================================
    // OnItemActionListener Callbacks
    // ==========================================

    @Override
    public void onIncrement(InventoryItem item) {
        int updatedQty = item.getQuantity() + 1;
        item.setQuantity(updatedQty);
        if (dbHelper.updateInventoryItem(item)) {
            adapter.notifyDataSetChanged();
        }
    }

    @Override
    public void onDecrement(InventoryItem item) {
        if (item.getQuantity() > 0) {
            int updatedQty = item.getQuantity() - 1;
            item.setQuantity(updatedQty);
            if (dbHelper.updateInventoryItem(item)) {
                adapter.notifyDataSetChanged();

                // Trigger Zero-Stock SMS notification workflow when quantity depletes to 0
                if (updatedQty == 0) {
                    handleZeroStockAlert(item.getName());
                }
            }
        }
    }

    @Override
    public void onDelete(InventoryItem item) {
        // Material confirmation dialog to prevent accidental deletion
        new AlertDialog.Builder(this)
                .setTitle("Delete Inventory Item")
                .setMessage("Are you sure you want to permanently delete \"" + item.getName() + "\" from inventory?")
                .setPositiveButton("Delete", (dialog, which) -> {
                    if (dbHelper.deleteInventoryItem(item.getId())) {
                        loadInventory();
                        Toast.makeText(this, "Item deleted", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // ==========================================
    // SMS Notification & Runtime Permission Workflow
    // ==========================================

    /**
     * Checks user preferences and SMS permission when an item hits zero quantity.
     */
    private void handleZeroStockAlert(String itemName) {
        pendingAlertItemName = itemName;
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        boolean smsEnabled = prefs.getBoolean(KEY_SMS_ENABLED, true);
        String phone = prefs.getString(KEY_ALERT_PHONE, DEFAULT_PHONE);

        // If user explicitly disabled SMS alerts on the SMS Notification Settings screen, respect choice
        if (!smsEnabled) {
            Toast.makeText(this, "Zero stock reached for '" + itemName + "' (SMS alerts disabled in settings).", Toast.LENGTH_SHORT).show();
            return;
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            dispatchSms(phone, "INVENTORY ALERT: Item '" + itemName + "' has reached 0 quantity!");
        } else {
            // Offer user the choice to grant permission immediately or open the dedicated SMS Settings screen
            new AlertDialog.Builder(this)
                    .setTitle("SMS Permission Required")
                    .setMessage("Item \"" + itemName + "\" has reached 0 stock. Grant SMS permission to send automated low-stock alerts, or open SMS Notification Settings.")
                    .setPositiveButton("Grant Permission", (dialog, which) ->
                            ActivityCompat.requestPermissions(InventoryActivity.this,
                                    new String[]{Manifest.permission.SEND_SMS},
                                    SMS_PERMISSION_REQUEST_CODE))
                    .setNeutralButton("SMS Settings Screen", (dialog, which) -> {
                        Intent intent = new Intent(InventoryActivity.this, SmsNotificationActivity.class);
                        startActivity(intent);
                    })
                    .setNegativeButton("Decline", (dialog, which) ->
                            Toast.makeText(this, "SMS alert skipped (permission not granted).", Toast.LENGTH_SHORT).show())
                    .show();
        }
    }

    /**
     * Dispatches an SMS message using SmsManager.
     */
    private void dispatchSms(String phoneNumber, String message) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "Low-stock SMS alert sent!", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Failed to dispatch SMS notification", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS permission granted.", Toast.LENGTH_SHORT).show();
                if (pendingAlertItemName != null) {
                    SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                    String phone = prefs.getString(KEY_ALERT_PHONE, DEFAULT_PHONE);
                    dispatchSms(phone, "INVENTORY ALERT: Item '" + pendingAlertItemName + "' has reached 0 quantity!");
                    pendingAlertItemName = null;
                }
            } else {
                // Graceful degradation: inform user but allow full app functionality
                Toast.makeText(this, "SMS notifications disabled by user.", Toast.LENGTH_LONG).show();
            }
        }
    }

    // ==========================================
    // Options Menu (Top Toolbar Navigation)
    // ==========================================

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_inventory, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_sms_settings) {
            Intent intent = new Intent(InventoryActivity.this, SmsNotificationActivity.class);
            startActivity(intent);
            return true;
        } else if (id == R.id.action_search) {
            Toast.makeText(this, "Search/Filter active", Toast.LENGTH_SHORT).show();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
