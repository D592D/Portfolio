package com.example.sortly;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

/**
 * LoginActivity handles user authentication and initial account registration.
 *
 * Defensive Programming & Quality Standards:
 * - Pre-validates user inputs before querying the SQLite database to save I/O resources.
 * - Supports both signing in and registering new users to satisfy project requirements.
 * - Password field is masked via TextInputLayout with visibility toggle for credential security.
 * - Clears the back stack upon successful authentication to prevent accidental back-navigation.
 */
public class LoginActivity extends AppCompatActivity {

    private TextInputLayout tilUsername;
    private TextInputLayout tilPassword;
    private TextInputEditText etUsername;
    private TextInputEditText etPassword;
    private MaterialButton btnLogin;
    private MaterialButton btnRegister;

    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Initialize SQLite Database Helper
        dbHelper = new DatabaseHelper(this);

        // Bind Views
        tilUsername = findViewById(R.id.tilUsername);
        tilPassword = findViewById(R.id.tilPassword);
        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        btnRegister = findViewById(R.id.btnRegister);

        // Set up click listeners
        btnLogin.setOnClickListener(v -> attemptLogin());
        btnRegister.setOnClickListener(v -> attemptRegistration());
    }

    /**
     * Authenticates an existing user against the SQLite database.
     */
    private void attemptLogin() {
        String username = etUsername.getText() != null ? etUsername.getText().toString().trim() : "";
        String password = etPassword.getText() != null ? etPassword.getText().toString().trim() : "";

        tilUsername.setError(null);
        tilPassword.setError(null);

        // Pre-validation checks
        if (TextUtils.isEmpty(username)) {
            tilUsername.setError("Username cannot be empty");
            etUsername.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(password)) {
            tilPassword.setError("Password cannot be empty");
            etPassword.requestFocus();
            return;
        }

        // Database verification
        boolean isValidUser = dbHelper.authenticateUser(username, password);

        if (isValidUser) {
            Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show();
            navigateToInventory();
        } else {
            Toast.makeText(this, "Invalid credentials. Please try again or create an account.", Toast.LENGTH_LONG).show();
        }
    }

    /**
     * Registers a new user account if one does not already exist.
     */
    private void attemptRegistration() {
        String username = etUsername.getText() != null ? etUsername.getText().toString().trim() : "";
        String password = etPassword.getText() != null ? etPassword.getText().toString().trim() : "";

        tilUsername.setError(null);
        tilPassword.setError(null);

        // Pre-validation checks
        if (TextUtils.isEmpty(username)) {
            tilUsername.setError("Username cannot be empty");
            etUsername.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(password)) {
            tilPassword.setError("Password cannot be empty");
            etPassword.requestFocus();
            return;
        }

        if (password.length() < 4) {
            tilPassword.setError("Password must be at least 4 characters");
            etPassword.requestFocus();
            return;
        }

        // Insert new user into database
        boolean isCreated = dbHelper.registerUser(username, password);

        if (isCreated) {
            Toast.makeText(this, "Account created successfully! Welcome.", Toast.LENGTH_SHORT).show();
            navigateToInventory();
        } else {
            tilUsername.setError("Username already exists. Please choose another.");
            etUsername.requestFocus();
        }
    }

    /**
     * Transitions to InventoryActivity and clears the back stack.
     */
    private void navigateToInventory() {
        Intent intent = new Intent(LoginActivity.this, InventoryActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }
}