package com.example.sortly;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

/**
 * AddItemActivity provides a dedicated, user-centered data entry form
 * to add new inventory records into the SQLite database.
 *
 * Defensive Programming & Quality Standards:
 * - Checks for non-empty string input on item names.
 * - Restricts and parses integers safely to prevent negative numbers and NumberFormatExceptions.
 * - Returns cleanly to InventoryActivity upon successful insertion.
 */
public class AddItemActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private TextInputLayout tilName;
    private TextInputLayout tilQuantity;
    private TextInputEditText etName;
    private TextInputEditText etQuantity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        dbHelper = new DatabaseHelper(this);

        tilName = findViewById(R.id.tilItemName);
        tilQuantity = findViewById(R.id.tilItemQuantity);
        etName = findViewById(R.id.etItemName);
        etQuantity = findViewById(R.id.etItemQuantity);

        MaterialButton btnSave = findViewById(R.id.btnSaveItem);
        MaterialButton btnCancel = findViewById(R.id.btnCancelItem);

        btnSave.setOnClickListener(v -> saveItem());
        btnCancel.setOnClickListener(v -> finish());
    }

    /**
     * Validates input fields and saves the new inventory record to the SQLite database.
     */
    private void saveItem() {
        String name = etName.getText() != null ? etName.getText().toString().trim() : "";
        String quantityStr = etQuantity.getText() != null ? etQuantity.getText().toString().trim() : "";

        tilName.setError(null);
        tilQuantity.setError(null);

        // Name validation
        if (TextUtils.isEmpty(name)) {
            tilName.setError("Item name cannot be empty");
            etName.requestFocus();
            return;
        }

        // Quantity validation
        if (TextUtils.isEmpty(quantityStr)) {
            tilQuantity.setError("Please enter an initial quantity");
            etQuantity.requestFocus();
            return;
        }

        int quantity;
        try {
            quantity = Integer.parseInt(quantityStr);
            if (quantity < 0) {
                tilQuantity.setError("Quantity cannot be negative");
                etQuantity.requestFocus();
                return;
            }
        } catch (NumberFormatException e) {
            tilQuantity.setError("Please enter a valid numeric integer");
            etQuantity.requestFocus();
            return;
        }

        // Insert into database
        InventoryItem newItem = new InventoryItem(name, quantity);
        boolean isInserted = dbHelper.insertInventoryItem(newItem);

        if (isInserted) {
            Toast.makeText(this, "Item added successfully", Toast.LENGTH_SHORT).show();
            finish(); // Returns to InventoryActivity
        } else {
            Toast.makeText(this, "Database insertion failed", Toast.LENGTH_SHORT).show();
        }
    }
}