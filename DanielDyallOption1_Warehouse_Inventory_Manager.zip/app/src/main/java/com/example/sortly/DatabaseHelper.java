package com.example.sortly;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

/**
 * SQLiteOpenHelper implementation for managing the local database.
 *
 * Architectural Decision:
 * - We implement two normalized relational tables: "Users" for credential management
 *   and "Inventory" for cataloged warehouse stock items.
 * - Offline-first reliability guarantees instant local data reads and writes without
 *   network latency.
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String TAG = "DatabaseHelper";
    private static final String DATABASE_NAME = "inventory_manager.db";
    private static final int DATABASE_VERSION = 1;

    // Users Table
    public static final String TABLE_USERS = "Users";
    public static final String COLUMN_USER_ID = "id";
    public static final String COLUMN_USER_USERNAME = "username";
    public static final String COLUMN_USER_PASSWORD = "password";

    // Inventory Table
    public static final String TABLE_INVENTORY = "Inventory";
    public static final String COLUMN_INV_ID = "id";
    public static final String COLUMN_INV_NAME = "name";
    public static final String COLUMN_INV_QUANTITY = "quantity";

    // SQL statement to create Users table
    private static final String TABLE_CREATE_USERS =
            "CREATE TABLE " + TABLE_USERS + " (" +
            COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            COLUMN_USER_USERNAME + " TEXT UNIQUE NOT NULL, " +
            COLUMN_USER_PASSWORD + " TEXT NOT NULL);";

    // SQL statement to create Inventory table
    private static final String TABLE_CREATE_INVENTORY =
            "CREATE TABLE " + TABLE_INVENTORY + " (" +
            COLUMN_INV_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            COLUMN_INV_NAME + " TEXT NOT NULL, " +
            COLUMN_INV_QUANTITY + " INTEGER NOT NULL DEFAULT 0);";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(TABLE_CREATE_USERS);
        db.execSQL(TABLE_CREATE_INVENTORY);

        // Pre-populate default admin credentials for immediate testing
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_USERNAME, "admin");
        values.put(COLUMN_USER_PASSWORD, "password123");
        db.insert(TABLE_USERS, null, values);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_INVENTORY);
        onCreate(db);
    }

    // ==========================================
    // User Authentication Operations
    // ==========================================

    /**
     * Registers a new user account in the SQLite database.
     *
     * @param username The chosen username.
     * @param password The chosen password.
     * @return true if successfully inserted, false if user already exists or error occurs.
     */
    public boolean registerUser(String username, String password) {
        if (username == null || username.trim().isEmpty() || password == null || password.trim().isEmpty()) {
            return false;
        }

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_USERNAME, username.trim().toLowerCase());
        values.put(COLUMN_USER_PASSWORD, password);

        long result = -1;
        try {
            result = db.insert(TABLE_USERS, null, values);
        } catch (Exception e) {
            Log.e(TAG, "Error during user registration", e);
        }
        return result != -1;
    }

    /**
     * Authenticates a user by username and password using parameterized queries.
     */
    public boolean authenticateUser(String username, String password) {
        if (username == null || username.trim().isEmpty() || password == null || password.trim().isEmpty()) {
            return false;
        }

        SQLiteDatabase db = this.getReadableDatabase();
        String selection = COLUMN_USER_USERNAME + " = ? AND " + COLUMN_USER_PASSWORD + " = ?";
        String[] selectionArgs = {username.trim().toLowerCase(), password};

        Cursor cursor = null;
        boolean isAuthenticated = false;
        try {
            cursor = db.query(TABLE_USERS, new String[]{COLUMN_USER_ID}, selection, selectionArgs, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                isAuthenticated = true;
            }
        } catch (Exception e) {
            Log.e(TAG, "Error during authentication query", e);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return isAuthenticated;
    }

    // ==========================================
    // CRUD Operations for Inventory
    // ==========================================

    /**
     * Create (Insert) a new inventory item.
     */
    public boolean insertInventoryItem(InventoryItem item) {
        if (item == null || item.getName() == null || item.getName().trim().isEmpty() || item.getQuantity() < 0) {
            return false;
        }

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_INV_NAME, item.getName().trim());
        values.put(COLUMN_INV_QUANTITY, item.getQuantity());

        long result = db.insert(TABLE_INVENTORY, null, values);
        return result != -1;
    }

    /**
     * Read (Select) all inventory items in alphabetical order.
     */
    public List<InventoryItem> getAllInventoryItems() {
        List<InventoryItem> items = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = null;
        try {
            cursor = db.query(TABLE_INVENTORY, null, null, null, null, null, COLUMN_INV_NAME + " ASC");
            if (cursor != null && cursor.moveToFirst()) {
                int idIndex = cursor.getColumnIndexOrThrow(COLUMN_INV_ID);
                int nameIndex = cursor.getColumnIndexOrThrow(COLUMN_INV_NAME);
                int qtyIndex = cursor.getColumnIndexOrThrow(COLUMN_INV_QUANTITY);

                do {
                    long id = cursor.getLong(idIndex);
                    String name = cursor.getString(nameIndex);
                    int qty = cursor.getInt(qtyIndex);
                    items.add(new InventoryItem(id, name, qty));
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.e(TAG, "Error fetching inventory items", e);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return items;
    }

    /**
     * Update an existing inventory item's quantity.
     */
    public boolean updateInventoryItem(InventoryItem item) {
        if (item == null || item.getId() <= 0 || item.getQuantity() < 0) {
            return false;
        }

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_INV_NAME, item.getName());
        values.put(COLUMN_INV_QUANTITY, item.getQuantity());

        String selection = COLUMN_INV_ID + " = ?";
        String[] selectionArgs = { String.valueOf(item.getId()) };

        int rows = db.update(TABLE_INVENTORY, values, selection, selectionArgs);
        return rows > 0;
    }

    /**
     * Delete an inventory item by ID.
     */
    public boolean deleteInventoryItem(long id) {
        SQLiteDatabase db = this.getWritableDatabase();
        String selection = COLUMN_INV_ID + " = ?";
        String[] selectionArgs = { String.valueOf(id) };

        int rows = db.delete(TABLE_INVENTORY, selection, selectionArgs);
        return rows > 0;
    }
}