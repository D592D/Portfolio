package com.example.sortly;

/**
 * Data model representing an item in the inventory.
 * 
 * We encapsulate the item details here rather than passing around loose variables.
 * This adheres to defensive programming by controlling access through getters and setters,
 * allowing us to add validation logic (e.g., preventing negative quantities) without 
 * changing the public API.
 */
public class InventoryItem {
    private long id;
    private String name;
    private int quantity;

    /**
     * Constructor for creating a new item without an ID (e.g., before inserting to DB).
     *
     * @param name     The name of the item.
     * @param quantity The initial quantity of the item.
     */
    public InventoryItem(String name, int quantity) {
        this.name = name;
        setQuantity(quantity); // Use setter to enforce validation
    }

    /**
     * Constructor for an existing item fetched from the database.
     *
     * @param id       The database ID.
     * @param name     The name of the item.
     * @param quantity The quantity of the item.
     */
    public InventoryItem(long id, String name, int quantity) {
        this.id = id;
        this.name = name;
        setQuantity(quantity);
    }

    public long getId() {
        return id;
    }
    
    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Item name cannot be null or empty.");
        }
        this.name = name;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        if (quantity < 0) {
            throw new IllegalArgumentException("Quantity cannot be negative.");
        }
        this.quantity = quantity;
    }
}
