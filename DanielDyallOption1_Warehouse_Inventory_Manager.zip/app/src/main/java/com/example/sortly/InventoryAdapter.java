package com.example.sortly;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;

import java.util.List;

/**
 * InventoryAdapter manages the binding of InventoryItem data to the 2-column grid.
 *
 * Decoupled Architecture:
 * - Uses an OnItemActionListener callback interface to delegate mutation events
 *   (increment, decrement, delete) back to the hosting Activity/Controller.
 */
public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.InventoryViewHolder> {

    public interface OnItemActionListener {
        void onIncrement(InventoryItem item);
        void onDecrement(InventoryItem item);
        void onDelete(InventoryItem item);
    }

    private List<InventoryItem> items;
    private final OnItemActionListener listener;

    public InventoryAdapter(List<InventoryItem> items, OnItemActionListener listener) {
        this.items = items;
        this.listener = listener;
    }

    public void updateData(List<InventoryItem> newItems) {
        this.items = newItems;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public InventoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_inventory, parent, false);
        return new InventoryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull InventoryViewHolder holder, int position) {
        InventoryItem item = items.get(position);

        holder.tvItemName.setText(item.getName());
        holder.tvQuantity.setText(String.valueOf(item.getQuantity()));

        // Semantic Color Indicator: Green for stock > 0, Red for 0
        if (item.getQuantity() > 0) {
            holder.tvQuantity.setTextColor(Color.parseColor("#4CAF50")); // Green
        } else {
            holder.tvQuantity.setTextColor(Color.parseColor("#F44336")); // Red
        }

        // Stepper button listeners
        holder.btnPlus.setOnClickListener(v -> {
            if (listener != null) {
                listener.onIncrement(item);
            }
        });

        holder.btnMinus.setOnClickListener(v -> {
            if (listener != null) {
                listener.onDecrement(item);
            }
        });

        // Delete button listener
        holder.btnDelete.setOnClickListener(v -> {
            if (listener != null) {
                listener.onDelete(item);
            }
        });
    }

    @Override
    public int getItemCount() {
        return items == null ? 0 : items.size();
    }

    static class InventoryViewHolder extends RecyclerView.ViewHolder {

        TextView tvItemName;
        TextView tvQuantity;
        MaterialButton btnPlus;
        MaterialButton btnMinus;
        ImageButton btnDelete;

        public InventoryViewHolder(@NonNull View itemView) {
            super(itemView);
            tvItemName = itemView.findViewById(R.id.tvItemName);
            tvQuantity = itemView.findViewById(R.id.tvQuantity);
            btnPlus = itemView.findViewById(R.id.btnPlus);
            btnMinus = itemView.findViewById(R.id.btnMinus);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }
}